using System.Reflection;

[assembly: AssemblyTitle("Cmd_GZip")]
[assembly: AssemblyDescription("gzip based file compression")]
[assembly: AssemblyCulture("")]
